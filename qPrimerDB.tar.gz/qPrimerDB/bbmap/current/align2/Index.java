package align2;

/**
 * @author Brian Bushnell
 * @date Dec 19, 2012
 *
 */
public abstract class Index {
	
	//TODO:  Put static methods here.
	
}
